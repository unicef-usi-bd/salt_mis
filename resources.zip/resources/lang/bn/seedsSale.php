<?php
return [
    'invoice_no' => 'চালান নং',
    'sale_date' => 'বিক্রয় তারিখ',
    'consumer_name' => 'ভোক্তার নাম',
    'contact_no' => 'যোগাযোগের নম্বর',
    'seeds_sale_create' => 'বীজ বিক্রয় তৈরি করুন',
    'price' => 'মূল্য',
    'sale_seeds_type' => 'বিক্রয় বীজ টাইপ',
    'ex_coustomer_name' => 'উদাহরণ: - এখানে গ্রাহক নাম',
    'ex_invoice_no' => 'উদাহরণ: - এখানে চালান নং',
    'ex_contact_no' => 'উদাহরণ: - এখানে যোগাযোগ নং',
    'ex_seeds_price' => 'এখানে বীজ দাম',
    'view_seeds_sale' => 'বীজ বিক্রয় দেখুন',
    'customer_details' => 'গ্রাহক বিবরণ',
    'sales_details' => 'বিক্রয় বিবরণ',
    'edit_seeds_sale' => 'বীজ বিক্রয় এডিট করুন',
    'delete_seeds_sale' => 'বীজ বিক্রয় মুছে দিন',
];
?>