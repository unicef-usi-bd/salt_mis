<?php
return [
    'crop_name_en' => 'ইংরেজিতে ফসলের নাম',
    'crop_name_bn' => 'বাংলায় ফসলের নাম',
    'used_for' => 'ব্যবহারের জন্য',
    'crop_type' => 'ফসলের টাইপ',
    'create_crop' => 'ফসল তৈরি করুন',
    'view_crop' => 'ফসল ',
    'edit_crop' => 'ফসল সম্পাদনা করুন',
    'delete_crop' => 'ফসল বাদ দিন',
    'ex_crop_name_en' => 'উদাহরণ :- ইংরেজিতে ফসলের নাম এখানে',
    'ex_crop_name_bn' => 'উদাহরণ :- বাংলায় ফসলের নাম এখানে',
];
?>