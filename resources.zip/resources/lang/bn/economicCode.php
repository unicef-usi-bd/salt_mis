<?php
return [
    'code_description' => 'কোড এর বর্ণনা',
    'physCodeUnit' => 'একক কোড',
    'transection' => 'লেনদেন হয়',
];
?>