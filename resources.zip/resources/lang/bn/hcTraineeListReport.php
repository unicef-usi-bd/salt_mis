<?php
return [
    'main_occupation' => 'প্রধান পেশা',
    'other_occupation' => 'অন্যান্য পেশা',
];
?>