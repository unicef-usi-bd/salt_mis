<?php
return [
    'fieldDay' => 'মাঠদিবসের প্রতিবেদনের সারসংক্ষেপ',
    'fieldDayTopic' => 'মাঠদিবসের বিষয়',

];
?>