<?php
return [
   'seeds_storage_report' => 'বীজ সংরক্ষণ প্রতিবেদন',
   'seeds_storage' => 'এনএটিপি-২ ডিএই প্রকল্পের আওতায় কৃষক কর্তৃক বীজ সংরক্ষণ প্রতিবেদন',
   'seeds_storage_farmer' => 'বীজ সংরক্ষণকারী কৃষক, সিআইজি এর নাম ও মোবাইল নং',
   'exhibit_crops' => 'প্রদর্শনীভুক্ত আউশ ফসল',
   'reserved_seeds_amount' => 'সংরক্ষিত বীজের পরিমান (কেজি)',
   'other_crops' => 'অন্যান্য ফসল',
   'crops_name' => 'ফসলের নাম',
];
?>