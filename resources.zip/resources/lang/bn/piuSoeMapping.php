<?php
return [
    'piu_soe_group_description' => 'পিআইউ এসঅঈ সমষ্টি বর্ণনা',
    'piu_group_report' => 'পিআইউ সমষ্টি প্রতিবেদন',
    'technology' => 'প্রযুক্তি',
    'piu_soe_mapping_create' => 'পিআইউ এসঅঈ ম্যাপিং তৈরি করুন',
];
?>