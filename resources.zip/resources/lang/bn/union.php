<?php
return [
    'union_name' => 'ইউনিয়নের নাম',
    'union_name_bn' => 'ইউনিয়নের নাম(বাংলা)',
    'union_code' => 'ইউনিয়নের কোড',
    'upazila_name' => 'উপজেলার নাম',
    'code' => 'কোড',
    'active_status' => 'সক্রিয় স্টেটাস',
    'union_create' => 'ইউনিয়ন তৈরি করুন',
    'exp_union_name' => 'উদাহরণ:- ইউনিয়নের নাম এখানে',
    'exp_union_name_bn' => 'উদাহরণ:- ইউনিয়নের নাম বাংলা এখানে',
    'exp_union_code' => 'উদাহরণ:- ইউনিয়নের কোড এখানে',
    'union_id' => 'ইউনিয়নের ক্রমিক',
    'union_list' =>'ইউনিয়নের তালিকা'
];
?>