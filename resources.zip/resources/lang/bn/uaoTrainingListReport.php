<?php
return [
    'trainee_attachment_no' => 'প্রশিক্ষণার্থীর তালিকার সংযুক্তি নং',

];
?>