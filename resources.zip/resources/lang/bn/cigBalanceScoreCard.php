<?php
return [
    'obtained_mark' => 'প্রাপ্ত মার্ক',
    'mark_percentage' => 'মার্ক শতাংশ',
    'total_obtained_mark' => 'মোট প্রাপ্ত মার্ক',
    'grade' => 'মান',
    'cig_category' => 'সিআইজি বিভাগ',
    'achieved_number' => 'প্রাপ্ত নাম্বার',
    'unit_weight_of_indicator' => 'নাম্বার সূচক',
];
?>