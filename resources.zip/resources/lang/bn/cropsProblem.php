<?php
return [
    'problem_title' => 'সমস্যার শিরোনাম',
    'technology' => 'প্রযুক্তি',
    'ex_crops_problem' => 'উদাহরণ: - এখানে ফসলের সমস্যা',
    'view_crops_problem' => 'ফসল সমস্যা দেখুন',
    'edit_crops_problem' => 'ফসলের সমস্যা এডিট করুন',
    'delete_crops_problem' => 'ফসলের সমস্যা বাদ দিন',
    'create_crops_problem' => 'ফসলের সমস্যা তৈরি করুন',
];
?>