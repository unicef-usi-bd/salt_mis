<?php
return [
    'bank_branch_create' => 'ব্যাংক শাখা তৈরি করুন',
    'branch_name' => 'শাখার নাম',
    'route_no' => 'রুট নং',
    'view_bank_branch' => 'ব্যাংক শাখা দেখুন',
    'edit_bank_branch' => 'ব্যাংক শাখা এডিট করুন',
    'delete_bank_branch' => 'ব্যাংক শাখা বাদ দিন',
    'ex_branch_name' => 'উদাহরণ: - এখানে ব্যাংক শাখার নাম',
    'ex_branch_phone' => 'উদাহরণ: - এখানে ব্যাংক শাখার ফোন নম্বর',
    'ex_route_no' => 'উদাহরণ: - এখানে ব্যাংক শাখার রুট নং',
];
?>