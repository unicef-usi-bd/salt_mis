<?php
return [
    'budget_revise_create' => 'বাজেট সংশোধন তৈরি করুন',
    'view_budget_revised' => 'সংশোধিত বাজেট দেখুন',
    'edit_budget_revised' => 'সংশোধিত বাজেট এডিট করুন',
];
?>