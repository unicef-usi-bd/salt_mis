<?php
 return[
     'module_link_list' => 'মডিউল লিঙ্কের তালিকা',
     'link_name' => 'লিঙ্কের নাম',
     'link_url' => 'লিঙ্কের ইয়উয়ারেল',
     'link_serial' => 'লিঙ্কের সিরিয়াল',
     'edit_link' => 'লিঙ্ক সম্পাদনা করুন',
     'delete_link' => 'মডিউল লিঙ্ক বাদ দিন',
     'module_link' => 'মডিউলের লিঙ্ক',
     'module_link_create' =>'মডিউলের লিঙ্ক তৈরি করুন',
     'create' => 'তৈরি করুন',
     'edit' => 'সম্পাদনা করুন',
     'delete' => 'বাদ দিন',
     'status' => 'অবস্থা',
     'view' => 'দেখুন',
     'update' => 'হালনাগাদ',
     'sl_no' => 'ক্রমিক নং',
     'module_links' => 'মডিউল লিংক'
 ];