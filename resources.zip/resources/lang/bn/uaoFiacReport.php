<?php
return [
    'time_period' => 'সময়কালঃ',
    'number' => 'সংখ্যা',
];
?>