<?php
return [
    'select' => 'নির্বাচন করা',
    'selected_cig_name' => 'নির্বাচিত সিআইজির নাম',
    'file_cig_name' => 'ফাইল সিআইজির নাম',
    'upload_excel_file_format' => 'এক্সেল ফাইল ফরম্যাট ডাউনলোড করুন',
    'upload_csv_file_format' => 'সিআসভি ফাইল ফরম্যাট ডাউনলোড করুন',
    'upload' => 'আপলোড',
    'file_upload' => 'ফাইল আপলোড',
    'only_excel_and_csv' => 'শুধুমাত্র এক্সেল এবং সিএসভি ফাইল দিতে হবে',
    'upload_farmer' => 'কৃষক আপলোড করুন',
];
?>