<?php
return [
    'cig_number' => 'সিআইজি সংখ্যা:',
    'cig_farmer_number' => 'সিআইজি কৃষক সংখ্যা:',
    'farmer_technology_taken' => 'প্রযুক্তি গ্রহণ / অনুসরণকারী কৃষকের সংখ্যা',
    'farmer_technology_report' => 'কৃষকের প্রযুক্তি গ্রহনের প্রতিবেদন',
];
?>