<?php
return [

    'cig_grading_list' => 'সিআইজি যাচাই তালিকা',
    'latter_grade' => 'অক্ষর যাচাই',
    'marks_from' => 'এই নাম্বার থেকে',
    'marks_to' => 'এই নাম্বার পর্যন্ত',
    'view_cig_grading' => 'সিআইজি যাচাই দেখুন',
    'edit_cig_grading' => 'সিআইজি যাচাই সম্পাদনা করুন',
    'delete_cig_grading' => 'সিআইজি যাচাই বাদ দিন',
    'cig_grading_create' => 'সিআইজি যাচাই তৈরি করুন',
    'ex_latter_grade' => 'উদাহরণ:- অক্ষর যাচাই এখানে',
    'ex_marks_from' => 'উদাহরণ:- এই নাম্বার থেকে এখানে',
    'ex_marks_to' => 'উদাহরণ:- এই নাম্বার পর্যন্ত এখানে',
    'ex_marks_remarks' => 'উদাহরণ:- মন্তব্য এখানে',
];
?>