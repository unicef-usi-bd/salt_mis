<?php
return [
    'economic_code' => 'অর্থনৈতিক কোড',
    'technology_subject' => 'প্রযুক্তি / বিষয়',
    'economic_code_technology_create' => 'অর্থনৈতিক কোড প্রযুক্তি তৈরি করুন',
    'economic_code_technology_edit' => 'অর্থনৈতিক কোড প্রযুক্তি এডিট করুন',
    'economic_code_technology_delete' => 'অর্থনৈতিক কোড প্রযুক্তি বাদ দিন',
];
?>