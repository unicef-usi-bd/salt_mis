<?php
return [
    'technology_type' => 'প্রযুক্তি প্রকার',
    'en' => '(ইংরেজি)',
    'bn' => '(বাংলা)',
    'economic_ode' =>'অর্থনৈতিক কোড'
];
?>