<?php
return [
    'fund_details' => 'তহবিল বিবরণ',
    'lender_name' => 'ঋণদাতার নাম',
    'installment' => 'কিস্তি',
    'amount' => 'পরিমাণ',
    'receive_date' => 'গ্রহণের তারিখ',
    'view_lender_fund' => 'ঋণদাতাকে দেখুন',
    'edit_lender_fund' => 'এডিট ঋণদাতা',
    'delete_lender_fund' => 'ঋণদাতাকে বাদ দিন',
    'lender_fund_details' => 'ঋণদাতাদের তহবিল বিস্তারিত',
    'lender' => 'ঋণদাতা',
    'receive_amount' => 'গ্রহণের পরিমাণ',
    'budget_amount' => 'বাজেট পরিমাণ',
    'balance_available' => 'ব্যবহারযোগ্য উদ্বৃত্ত অংশ',
    'lender_fund_create' => 'ঋণদাতা তহবিল তৈরি করুন',
    'lender_fund_list' => 'ঋণদাতা তহবিল তালিকা',
    'financial_year' => 'আর্থিক বছর'
];
?>