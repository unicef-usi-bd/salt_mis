<?php
return [
    'name' => 'নাম',
    'abbreviation' => 'সংক্ষিপ্ত নাম',
    'user_define_id' => 'ব্যবহারকারী নির্ধারিত ক্রমিক',
    'description' => 'বিবরণ',
    'status' => 'স্টেটাস',
    'action' => 'কর্মপ্রক্রিয়া',
    'view_lookup' => 'লুকআপ দেখুন',
    'edit_lookup' => 'লুকআপ সম্পাদনা করুন',
    'sl' => 'ক্রমিক',
    'create_lookup' => 'লুকআপ গ্রুপ তৈরি',
    'group_name' => 'গ্রুপের নাম',
    'active_status' => 'সক্রিয় স্টেটাস',
    'exp_group_name' => 'উদাহরণ:- গ্রুপের নাম এখানে',
    'exp_user_define_id' => 'উদাহরণ:- ব্যবহারকারী নির্ধারিত ক্রমিক এখানে',
    'view_lookup_group_data' => 'লুকআপ গ্রুপ ডাটা দেখুন',
    'edit_lookup_group_data' => 'এডিট লুকআপ গ্রুপ ডাটা',
    'delete_lookup_group_data' => 'লুকআপ গ্রুপ ডাটা বাদ দিন',
    'group_data_name' => 'গ্রুপ ডাটা নাম',
    'lookup_group_data_list' => 'লুকআপ গ্রুপ ডাটা তথ্য তালিকা',
    'lookup_group_data_create' => 'লুকআপ গ্রুপ ডেটা তৈরি করুন'
];
?>