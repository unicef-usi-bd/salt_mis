<?php
return [
    'vermi_compost_report' => 'ভার্মি কম্পোষ্ট প্রতিবেদন',
    'compost_amount' => 'বছরে উৎপাদিত কম্পোষ্টের গড় পরিমান',
    'kg' => '(কেজি)',
    'compost' => 'কম্পোষ্ট',
    'vermiCompost' => 'ভার্মি কম্পোষ্ট',
];
?>