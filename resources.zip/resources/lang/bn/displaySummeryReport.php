<?php
return [
    'display_summery' => 'প্রদর্শণী প্রতিবেদনের সারসংক্ষেপ',
    'tech_name' => 'প্রযুক্তির নাম',
];
?>