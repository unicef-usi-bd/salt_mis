<?php
return [
    'org_list' => 'সংস্থার তালিকা',
    'logo' => 'লোগো',
    'organization' => 'প্রতিষ্ঠান',
    'org_status' => 'স্ট্যাটাস',
    'org_group' => 'গ্রুপ',
    'org_user' => 'ব্যবহারকারী',
    'org_modules' => 'মডিউল',
    'org_pages' => 'পেজ',
    'create_group' => 'গ্রুপ তৈরি করুন',
    'create_user' => 'ব্যবহারকারী তৈরি করুন',
    'assign_modules' => 'মডিউল বরাদ্দ করুন',
    'add_pages' => 'পেজ যোগ করুন',
    'module_name' => 'মডিউলের নাম',
    'organization_module' => 'সংস্থার মডিউল'
];