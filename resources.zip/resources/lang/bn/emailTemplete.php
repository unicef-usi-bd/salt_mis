<?php
return [
    'email_type_name' => 'ইমেইল টাইপের নাম',
    'subject' => 'বিষয়',
    'view_email_template' => 'ইমেইল টেমপ্লেট দেখুন',
    'edit_email_template' => 'ইমেইল টেমপ্লেট এডিট করুন',
    'delete_email_template' => 'ইমেইল টেমপ্লেট বাদ দিন',
    'create_email_template' => 'ইমেইল টেমপ্লেট তৈরি করুন',
    'ex_email_subject' => 'উদাহরণ: - এখানে ইমেইলের বিষয়',
];
?>