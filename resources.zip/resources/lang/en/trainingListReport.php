<?php
return [
    'tl_report' => 'Training report list',
    'batch_no' => 'Batch No',
    'date' => 'Date',
    'start' => 'Start',
    'number_days' => 'How many days ?',
    'trainee_type' => 'Trainee type',
    'total_trainee_avaiable' => 'Number of Total Trainees Available',
    'male' => 'Male',
    'female' => 'Female',
    'ethnic_trainee' => 'How many of the small ethnic groups in the trainees',
];
?>