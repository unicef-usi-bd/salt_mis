<?php
return [
    'invoice_no' => 'Invoice No',
    'sale_date' => 'Sale Date',
    'consumer_name' => 'Consumer Name',
    'contact_no' => 'Contact No',
    'seeds_sale_create' => 'Seeds Sale Create',
    'price' => 'Price',
    'sale_seeds_type' => 'Sale Seeds Type',
    'ex_coustomer_name' => 'Example:- Customer name here',
    'ex_invoice_no' => 'Example:- Invoice No here',
    'ex_contact_no' => 'Example:- Contact No here',
    'ex_seeds_price' => 'Seeds Price here',
    'view_seeds_sale' => 'View Seeds Sale',
    'customer_details' => 'Customer Details',
    'sales_details' => 'Sales Details',
    'edit_seeds_sale' => 'Edit Seeds Sale',
    'delete_seeds_sale' => 'Delete Seeds Sale',
    'stock_quantity' => 'Stock Quantity',
    'ex_stock_quantity' => 'Stock Quantity here'
];
?>