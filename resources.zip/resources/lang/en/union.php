<?php
return [
    'union_name' => 'Union Name',
    'union_name_bn' => 'Union Name(Bangla)',
    'union_code' => 'Union Code',
    'upazila_name' => 'Upazila Name',
    'code' => 'Code',
    'active_status' => 'Active Status',
    'union_create' => 'Union Create',
    'exp_union_name' => 'Example:- Union name here',
    'exp_union_name_bn' => 'Example:- Union name bangla here',
    'exp_union_code' => 'Example:- Union code here',
    'union_id' => 'Union Id',
    'union_list' => 'Union List'
];
?>