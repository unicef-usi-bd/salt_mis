<?php
return [
    'main_occupation' => 'Main occupation',
    'other_occupation' => 'Other Occupation',
];
?>