<?php
return [
    'bank_name' => 'Banks Name',
    'bank_create' => 'Bank Create',
    'ex_bank_name' => 'Example:- Bank name here',
    'ex_bank_address' => 'Example:- Bank Address Here ',
    'ex_email_address' => 'Example:- Email Address here',
    'ex_phone' => 'Example:- Phone Number here',
    'edit_bank' => 'Edit Bank',
    'view_bank' => 'View Bank',
    'delete_bank' => 'Delete Bank',
];
?>