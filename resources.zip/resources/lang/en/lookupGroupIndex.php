<?php
return [
    'name' => 'Name',
    'abbreviation' => 'Abbreviation',
    'user_define_id' => 'User Define ID',
    'description' => 'Description',
    'status' => 'Status',
    'action' => 'Action',
    'view_lookup' => 'View Lookup',
    'edit_lookup' => 'Edit Lookup',
    'sl' => 'SL',
    'create_lookup' => 'Lookup Group Create',
    'group_name' => 'Group Name',
    'active_status' => 'Status',
    'exp_group_name' => 'Group Name Here',
    'exp_user_define_id' => 'User Define Serial Number Here',
    'view_lookup_group_data' => 'View Lookup Group Data',
    'edit_lookup_group_data' => 'Edit Chemical Per KG',
    'delete_lookup_group_data' => 'Delete Lookup Group Data',
    'group_data_name' => 'Group Data Name',
    'lookup_group_data_list' => 'Lookup Group Data List',
    'lookup_group_data_create' => 'Lookup Group Data Create'
];
?>