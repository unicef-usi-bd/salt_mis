<?php
return [
    'ccType' => 'Cost Center.Type',
    'cost_center' => 'Cost Center',
    'search' => 'Search',
    'receiver_list' => 'Receiver List',
    'cc' => 'CC',
    'bcc' => 'BCC',
    'send_email' => 'Send Email',
    'address' => 'Address',
    'email' => 'Email',
    'phone' => 'Phone',
    'status' => 'Status',
];
?>