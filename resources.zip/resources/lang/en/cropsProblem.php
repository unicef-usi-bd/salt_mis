<?php
return [
    'problem_title' => 'Problem Title',
    'technology' => 'Technology',
    'ex_crops_problem' => 'Example :- crops problem here',
    'view_crops_problem' => 'View Crops Problem',
    'edit_crops_problem' => 'Edit Crops Problem',
    'delete_crops_problem' => 'Delete Crops Problem',
    'create_crops_problem' => 'Crops Problem Create',
];
?>