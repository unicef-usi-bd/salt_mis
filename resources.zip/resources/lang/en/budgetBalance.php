<?php
return [
    'ecode' => 'Economic Code',
    'budget_amount' => 'Budget Amount',
    'allocation_amount' => 'Allocation Amount',
    'remain_amount' => 'Remain Balance',

];
?>