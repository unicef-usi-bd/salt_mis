<?php
return [
    'start_date' => 'Start Date',
    'end_date' => 'End Date',
    'current_year' => 'Current Year',
    'is_current' => 'Is Current',
    'year_name' => 'Year Name',
    'ex_financial_year_name' => 'Example:- Financial Year Name Here',
];
?>