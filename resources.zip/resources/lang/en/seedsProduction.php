<?php
return [
    'production_date' => 'Production date',
    'seeds_type' => 'Seeds Type',
    'quantity' => 'Quantity',
    'view_seeds_production' => 'View Seeds Production',
    'create_seeds_production' => 'Seeds Production Create',
    'date' => 'Date',
    'comments' => 'Comment',
    'edit_seeds_production' => 'Edit Seeds Production',
    'delete_seeds_production' => 'Delete Seeds Production',
    'ex_quantity' => 'Quantity Here',
    'ex_comments' => 'Comments Here',
];
?>