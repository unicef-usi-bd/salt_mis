<?php
return [
    'cig_type' => 'CIG Type',
    'upazila_cig_number' => 'Number of CIGs of the upazila',
    'number_ethnic_cig' => 'Members of ethnic / tribal population are included in how many CIGs',
    'number_ethnic_cig_member' => 'Number of members of ethnic group / tribal population included in the CIG',
    'number_ethnic_cig_display_member' => 'CIG-member of the ethnic / tribal population included in how many CIGs participated in project training / exhibition activities',
    'display' => 'Exhibition',
    'uao_ethnic' => 'Primary report related to ethnic / tribal population participation',
];
?>