<?php
return[
    'trainee_category_name' => 'Trainee Category Name',
    'cost_center_type' => 'Cost Center Type',
    'trainee_list' => 'Trainee List',
    'view' => 'View Trainee Category',
    'edit' => 'Edit Trainee Category',
    'delete' => 'Delete Trainee Category',
    'trainee_category' => 'Trainee Category Create',
    'trainee_category1' => 'Trainee Category'
];