<?php
return [
    'vermi_compost_report' => 'Vermi Compost Report',
    'compost_amount' => 'The average amount of compost produced in the year',
    'kg' => '(Kg)',
    'compost' => 'Compost',
    'vermiCompost' => 'Vermi compost',
];
?>