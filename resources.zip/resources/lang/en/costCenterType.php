<?php
return [
    'cost_center_type_name' => 'Cost Center Type Name',
    'cost_center_type_create' => 'Cost Center Type Create',
    'edit_cost_center_type' => 'Edit Cost Center Type',
    'delete_cost_center_type' => 'Delete Cost Center Type',
    'example_cost_center_type_name'=> 'Example:- Cost center Type Name here'
];
?>