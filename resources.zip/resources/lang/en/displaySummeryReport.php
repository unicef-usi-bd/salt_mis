<?php
return [
    'display_summery' => 'Exhibit Report Summary',
    'tech_name' => 'Technology name',
];
?>