<?php
return [
    'crop_name_en' => 'Crop Name English',
    'crop_name_bn' => 'Crop Name Bangla',
    'used_for' => 'Used For',
    'crop_type' => 'Crops Type',
    'create_crop' => 'Crops Create',
    'view_crop' => 'View Crops',
    'edit_crop' => 'Edit Crops',
    'delete_crop' => 'Delete Crops',
    'ex_crop_name_en' => 'Crops name in English here',
    'ex_crop_name_bn' => 'Crops name in Bangla here',
];
?>