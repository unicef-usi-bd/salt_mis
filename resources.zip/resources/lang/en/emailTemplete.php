<?php
return [
    'email_type_name' => 'Email Type Name',
    'subject' => 'Subject',
    'view_email_template' => 'View Email Template',
    'edit_email_template' => 'Edit Email Template',
    'delete_email_template' => 'Delete Email Template',
    'create_email_template' => 'Email Template Create',
    'ex_email_subject' => 'Example:- Email Subject here',
];
?>