<?php
return [
    'topic' => 'Training topics',
    'allocate_number' => 'Allocated (number)',
    'kharip-1' => 'Kharip-1',
    'kharip-2' => 'Kharip-2',
    'Robi' => 'Robi',
    'total' => 'Total',
    'comment' => 'Comment',
    'ts_report' => 'Training Report Summary',

];
?>