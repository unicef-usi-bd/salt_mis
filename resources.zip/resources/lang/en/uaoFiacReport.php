<?php
return [
    'time_period' => 'Time period',
    'number' => 'Number',

];
?>