<?php
return [
    'traineeListLink' => 'Did the trainee.php list have been linked (yes / no)',

];
?>