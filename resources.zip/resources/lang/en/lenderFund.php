<?php
return [
    'fund_details' => 'Fund Details',
    'lender_name' => 'Lender name',
    'installment' => 'Installment',
    'amount' => 'Amount',
    'receive_date' => 'Receive Date',
    'view_lender_fund' => 'View Lander Fund',
    'edit_lender_fund' => 'Edit Lander Fund',
    'delete_lender_fund' => 'Delete Lander Fund',
    'lender_fund_details' => 'lender Fund Details',
    'lender' => 'Lender',
    'receive_amount' => 'Receive Amount',
    'budget_amount' => 'Budget Amount',
    'balance_available' => 'Balance Available',
    'lender_fund_create' => 'Lender Fund Create',
    'lender_fund_list' => 'Lender Fund List',
    'financial_year' => 'Financial Year'
];
?>