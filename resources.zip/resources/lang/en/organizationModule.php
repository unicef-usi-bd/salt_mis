<?php
return [
    'org_list' => 'Organization List',
    'logo' => 'Logo',
    'organization' => 'Organization',
    'org_status' => 'Status',
    'org_group' => 'Group',
    'org_user' => 'User',
    'org_modules' => 'Modules',
    'org_pages' => 'Pages',
    'create_group' => 'Create Group',
    'create_user' => 'Create User',
    'assign_modules' => 'Assign Modules',
    'add_pages' => 'Add Pages',
    'module_name' => 'Module Name',
    'organization_module' => 'Organization Module'
];