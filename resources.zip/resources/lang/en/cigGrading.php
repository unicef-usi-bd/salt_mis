<?php
return [
    'cig_grading_list' => 'CIG Grading List',
    'latter_grade' => 'Latter Grade',
    'marks_from' => 'Marks From',
    'marks_to' => 'Marks To',
    'view_cig_grading' => 'View CIG Grading',
    'edit_cig_grading' => 'Edit CIG Grading',
    'delete_cig_grading' => 'Delete CIG Grading',
    'cig_grading_create' => 'CIG Grading Create',
    'ex_latter_grade' => 'Example:- Latter Grade here',
    'ex_marks_from' => 'Example:- Marks From Here',
    'ex_marks_to' => 'Example:- Marks From To',
    'ex_marks_remarks' => 'Example:- Remarks Here',
];
?>