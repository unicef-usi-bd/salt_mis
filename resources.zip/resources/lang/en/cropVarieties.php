<?php
return [
    'crops_varieties_name' => 'Crops Varieties Name',
    'ex_crops_varieties_name' => 'Crop Varieties name here',
    'crops_name' => 'Crops Name',
    'view_crops_varieties' => 'View Crops Varieties',
    'edit_crops_varieties' => 'Edit Crops Varieties',
    'delete_crops_varieties' => 'Delete Crops Varieties',
    'create_crops_varieties' => 'Crops Varieties Create',
];
?>