<?php
return [
    'seeds_name' => 'The name of the production seed / pen',
    'cast_name' => 'Cast name',
    'number_seeds_produce' => 'Number of seedlings / pens produced',
    'seeds_info' => 'Produced seed / pen information',
];
?>