<?php
return [
    'seeds_storage_report' => 'Seeds Storage Report',
    'seeds_storage' => 'Seeds Storage Report by farmer implemented under the NATP-2 DAE project',
    'seeds_storage_farmer' => 'Seed storage farmers, CIG\'s name and mobile no',
    'exhibit_crops' => 'Exhibit Aush Crop',
    'reserved_seeds_amount' => 'Reserved Seed Amount (kg)',
    'other_crops' => 'Other crops',
    'crops_name' => 'Crop name',
];
?>