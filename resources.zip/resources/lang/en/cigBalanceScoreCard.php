<?php
return [
    'obtained_mark' => 'Obtained Mark',
    'mark_percentage' => 'Mark Percentage',
    'total_obtained_mark' => 'Total obtained Mark ',
    'grade' => 'Grade',
    'cig_category' => 'CIG Category',
    'achieved_number' => 'Achieved Number',
    'unit_weight_of_indicator' => 'Unit Weight of indicator',
];
?>