<?php
return [
    'cig_name' => 'CIG\'s name, block, union',
    'farmer_name' => 'Farmer\'s name',
    'land_amount' => 'The amount of land currently cultivated (Satak)',
    'own' => 'Own',
    'barga/lease' => 'Barga / lease',
    'main_crops' => 'The name of the main crop produced',

];
?>