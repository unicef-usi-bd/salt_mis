<?php
return [
    'name' => 'Name',
    'address' => 'Address',
    'email' => 'Email',
    'fax' => 'Fax',
    'org_type' => 'Organization Type',
    'slogan' => 'Slogan',
    'website' => 'Website',
    'logo' => 'Logo',
    'phone' => 'Phone',
    'bank_info' => 'Bank Information',
    'bank_name' => 'Bank Name',
    'branch_name' => 'Branch Name',
    'account_no' => 'Account No.',
    'route_no' => 'Route no.',
    'organisation_create' => 'Organisation Create',
    'view_organisation' => 'View Organisation',
    'edit_organisation' => 'Edit Organisation',
    'delete_organisation' => 'Delete Organisation',
    'select_one' => 'Select One'
];
?>