<?php
return [
    'activity_type' => 'Activity type',
    'unit_cost' => 'Unit Cost',
    'cost_center_type' => 'Cost Center Type',
    'ex_unit_cost' => 'Example:- Unit Cost here',
    'technology_unit_cost' => 'Technology Unit Cost Create',
    'edit_technology_cost' => 'Edit Technology Unit cost',
    'view_technology_cost' => 'View Technology Unit cost',
    'delete_technology_cost' => 'Delete Technology Unit cost'
];
?>