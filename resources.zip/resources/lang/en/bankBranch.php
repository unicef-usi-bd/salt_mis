<?php
return [
    'bank_branch_create' => 'Bank Branch Create',
    'branch_name' => 'Branch Name',
    'route_no' => 'Route No',
    'view_bank_branch' => 'View Bank Branch',
    'edit_bank_branch' => 'Edit Bank Branch',
    'delete_bank_branch' => 'Delete Bank Branch',
    'ex_branch_name' => 'Example:- Bank Branch name here',
    'ex_branch_phone' => 'Example:- Bank branch Phone Number here',
    'ex_route_no' => 'Example:- Bank branch Route Number here',

];
?>