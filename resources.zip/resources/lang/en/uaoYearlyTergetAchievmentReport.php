<?php
return [
    'amount_land' => 'The amount of land (O :)',
    'finalYear' => 'Financial Year:',
    'yeild' => 'Yield (Mt.)',
    'year_wise_yeild' => 'Year-wise yield target and achievement report',

];
?>