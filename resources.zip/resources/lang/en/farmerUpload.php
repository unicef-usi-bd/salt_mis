<?php
return [
    'select' => 'select',
    'selected_cig_name' => 'Selected CIG name',
    'file_cig_name' => 'File CIG name',
    'upload_excel_file_format' => 'Download Excel File Format',
    'upload_csv_file_format' => 'Download CSV File Format',
    'upload' => 'Upload',
    'file_upload' => 'File Upload',
    'only_excel_and_csv' => 'Only Excel and CSV File will excepted',
    'upload_farmer' => 'Upload Farmer',
];
?>