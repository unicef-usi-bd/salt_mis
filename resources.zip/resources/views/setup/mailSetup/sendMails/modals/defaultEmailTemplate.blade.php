<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<h1>{{ $data['email_subject'] }}</h1>
<p>{!! $data['email_body'] !!}</p>
</body>
</html>