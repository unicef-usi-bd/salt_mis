{{--<div class="footer">--}}
	{{--@include('masterGlobal.modalGlobal')--}}
    {{--<div class="footer-inner">--}}
        {{--<div class="footer-content">--}}
						{{--<span class="bigger-120">--}}
							{{--<span class="blue bolder">{{ Session::get('orgName') }}</span>--}}
							{{--Application &copy; 2018--}}
						{{--</span>--}}

            {{--&nbsp; &nbsp;--}}
            {{--<span class="action-buttons">--}}
							{{--<a href="#">--}}
								{{--<i class="ace-icon fa fa-twitter-square light-blue bigger-150"></i>--}}
							{{--</a>--}}

							{{--<a href="#">--}}
								{{--<i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i>--}}
							{{--</a>--}}

							{{--<a href="#">--}}
								{{--<i class="ace-icon fa fa-rss-square orange bigger-150"></i>--}}
							{{--</a>--}}
						{{--</span>--}}
        {{--</div>--}}
    {{--</div>--}}
{{--</div>--}}

{{--<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">--}}
    {{--<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>--}}
{{--</a>--}}

<div class="footer">
	@include('masterGlobal.modalGlobal')
	<div class="footer-inner">
		<div class="footer-content">
			<div class="pull-left" style="height:100%;">
				<span style="vertical-align:middle;">Implemented BY </span>
				<img src="image/association-logo.png" width="150" height="40" alt="Association Logo"/>
			</div>
			<div class="pull-right" style="height:100%;">
				<span style="vertical-align:middle;">Supported BY </span>
				<img src="image/unicef-bd.jpg" width="50" height="40" alt="Association Logo"/>
			</div>
		</div>
	</div>
</div>
