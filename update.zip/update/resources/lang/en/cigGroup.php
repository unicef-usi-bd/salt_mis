<?php
return [

    'cig_name' => 'CIG Name',
    'upazilla' => 'Upazilla',
    'union' => 'Union',
    'village' => 'Village',
    'region' => 'Region',
    'district' => 'District',
    'cig_type' => 'CIG Type',
    'cig' => 'CIG',
    'establish_date' => 'Establish Date',
    'bank_name' => 'Bank Name',
    'branch_name' => 'Branch',
    'bank_account' => 'Account no',
    'cig_create' => 'CIG Create',
    'active_status' => 'Active Status',
    'ex_village_name' => 'Example: - Village name here',
    'ex_cig_name' => 'Example:- Cig name here',
    'ex_bank_account' => 'Example:- Bank account here',
    'view_cig' => 'View CIG',
    'edit_cig' => 'Edit CIG',
    'delete_cig' => 'Delete CIG',
    'cig_list' => 'CIG List',
    'cig_gender' => 'CIG Gender'
];
?>