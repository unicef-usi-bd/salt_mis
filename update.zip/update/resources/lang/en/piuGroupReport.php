<?php
 return [
     'group_report' => 'Group Report Id',
     'category_no' => 'Category No',
     'description' => 'Description',
     'summary' => 'Summary Sheet No',
     'active_status' => 'Active Status',
     'ex_description' => 'Example:- Description',
     'ex_summary' => 'Example:- Summery Sheet No',
     'ex_category' => 'Example:- Category No',
     'title_create' => 'PIU Group Report Create',
     'title_edit' => 'PIU Group Report edit',
     'view' => 'PIU Group Report View',
     'title_view' => 'PIU Group Report Details',
     'general_setup' => 'General Setup',
     'piu_group_report' => 'PIU Group Report'
 ];
?>