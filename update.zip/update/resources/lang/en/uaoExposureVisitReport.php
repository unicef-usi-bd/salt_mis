<?php
return [
    'exposure_visit' => 'Exposure Visits Report',
    'place' => 'Place',
    'participants_type' => 'Participants type',
    'total_participants_present' => 'Total number of participants present',
    'participants_ethnic_present' => 'How many of the small ethnic groups among the participants',
];
?>