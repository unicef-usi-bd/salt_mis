<?php
return [
    'trainee_attachment_no' => 'Attachment No. of Trainees List',

];
?>