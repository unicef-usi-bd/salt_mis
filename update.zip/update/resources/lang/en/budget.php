<?php
return [
    'financial_year' => 'Financial Year',
    'source_type' => 'Source Type',
    'budget_type' => 'Budget Type',
    'amount' => 'Amount',
    'govt' => 'Govt ',
    'rpa' => 'RPA ',
    'total_available' => 'Total Available',
    'adp_amount' => 'Adp Amount',
    'budget_create' => 'Budget Create',
    'view_budget' => 'View budget',
    'edit_budget' => 'Edit Budget',
    'delete_budget' => 'Delete budget',
    'adp_budget_date' => 'ADP Budget Date',
    'revised_budget_date' => 'Revised Budget Date',
    'revised_budget_amount' => 'Revised Amount',
    'technology' => 'Technology',

];
?>