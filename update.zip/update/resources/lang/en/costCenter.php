<?php
return [
    'upazilla_type' => 'Upazilla Type',
    'cost_center_user' => 'Cost Center User List',
    'account_name' => 'Account Name'
];
?>