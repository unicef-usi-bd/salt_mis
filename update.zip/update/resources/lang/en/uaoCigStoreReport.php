<?php
return [
    'cigStore' => 'CIG stores and registers Report',
    'cigNumber' => 'CIG Number',
];
?>