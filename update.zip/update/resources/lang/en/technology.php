<?php
return [
    'technology_type' => 'Technology Type',
    'en' => '(English)',
    'bn' => '(Bangla)',
    'economic_ode' =>'Economic Code'
];
?>