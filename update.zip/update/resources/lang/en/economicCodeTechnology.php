<?php
return [
    'economic_code' => 'Economic Code',
    'technology_subject' => 'Technology / Subject',
    'economic_code_technology_create' => 'Economic code Technology Create',
    'economic_code_technology_edit' => 'Edit Economic Code Technology',
    'economic_code_technology_delete' => 'Delete Economic Code Technology',
];
?>