<?php
return [
    'code_description' => 'Code Description',
    'physCodeUnit' => 'Phys. Code Unit',
    'transection' => 'Is Transection',
];
?>