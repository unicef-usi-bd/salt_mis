<?php
return [
    'cig_number' => 'CIG Number:',
    'cig_farmer_number' => 'CIG Number of Farmers:',
    'farmer_technology_taken' => 'Technology adoption / number of peasants following',
    'farmer_technology_report' => 'Farmer\'s technology acceptance report',
];
?>