<?php
return [
    'trainee_list_report' => 'Trainee list',
    't_score' => 'Trainer Scoring',
    'trainee_name' => 'Trainee name',
    'designation' => 'Designation',
    'address' => 'Work / address',
    'mobile' => 'Mobile number',
    'tribe' => 'Tribe',
    'yes/no' => 'Yes/No',
    'age' => 'Age',
];
?>