<?php
return [
    'field_day_list' => 'Field day report List',
    'field_day_date' => 'Field Day Date',
    'field_day_place' => 'Field day Place',
    'present_officer' => 'Number of officials present',
    'present_representative' => 'Number of representatives present',
    'present_farmer' => 'Number of peasants present',
    'cig' => 'CIG',
    'non-cig' => 'Non-CIG',
];
?>