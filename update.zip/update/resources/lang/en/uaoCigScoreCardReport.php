<?php
return [
    'union_name' => 'Union name',
    'grade' => 'Grade (CIG Number)',
    'veryGood' => 'Very good',
    'good' => 'Good',
    'medium' => 'Medium',
    'notGood' => 'Not good',
    'totalCig' => 'Total CIG',

];
?>