<?php
return [
    'piu_soe_group_description' => 'PIU SOE Group Description',
    'piu_group_report' => 'PIU Group Report',
    'technology' => 'Economic Code',
    'piu_soe_mapping_create' => 'PIU SOE Mapping Create',
];
?>