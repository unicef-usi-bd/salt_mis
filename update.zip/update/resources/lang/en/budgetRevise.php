<?php
return [
    'budget_revise_create' => 'Budget Revise Create',
    'view_budget_revised' => 'View Budget Revised',
    'edit_budget_revised' => 'Edit Budget Revised',


];
?>