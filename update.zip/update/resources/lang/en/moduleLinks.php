<?php
 return[
     'module_link_list' => 'Module Link List',
     'link_name' => 'Link Name',
     'link_url' => 'Link URL',
     'link_serial' => 'Link Serial',
     'edit_link' => 'Edit Link',
     'delete_link' => 'Delete Link',
     'module_link' => 'Module Link',
     'module_link_create' =>'Module Link Create',
     'create' => 'Create',
     'edit' => 'Edit',
     'delete' => 'Delete',
     'status' => 'Status',
     'view' => 'View',
     'update' => 'Update',
     'sl_no' => 'SL No.',
     'module_links' => 'Module Links'
 ];