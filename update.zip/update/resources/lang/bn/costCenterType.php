<?php
return [
    'cost_center_type_name' => 'খরচ কেন্দ্র টাইপ নাম',
    'cost_center_type_create' => 'খরচ কেন্দ্র প্রকার তৈরি করুন',
    'edit_cost_center_type' => 'খরচ কেন্দ্র প্রকার এডিট করুন',
    'delete_cost_center_type' => 'খরচ কেন্দ্র প্রকার বাদ দিন',
    'example_cost_center_type_name'=> 'উদাহরণ: - খরচ কেন্দ্রের নাম এখানে'
];
?>