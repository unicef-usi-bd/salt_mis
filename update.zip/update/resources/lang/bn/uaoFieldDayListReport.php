<?php
return [
    'field_day_list' => 'মাঠদিবসের প্রতিবেদনের ছক',
    'field_day_date' => 'মাঠ দিবসের তারিখ',
    'field_day_place' => 'মাঠ দিবসের স্থান',
    'present_officer' => 'উপস্থিত কর্মকর্তার সংখ্যা',
    'present_representative' => 'উপস্থিত জনপ্রতিনিধির সংখ্যা',
    'present_farmer' => 'উপস্থিত কৃষকের সংখ্যা',
    'cig' => 'সিআইজি',
    'non-cig' => 'নন-সিআইজি',

];
?>