<?php
return [
    'seeds_name' => 'উৎপাদিত চারা/কলমের নাম',
    'cast_name' => 'জাতের নাম',
    'number_seeds_produce' => 'উৎপাদিত চারা/কলমের সংখ্যা',
    'seeds_info' => 'উৎপাদিত চারা/কলমের তথ্য',
];
?>