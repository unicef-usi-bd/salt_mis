<?php
return [
    'trainee_list_report' => 'প্রশিক্ষণার্থীর তালিকা',
    't_score' => 'প্রশিক্ষণার্থীর ক্রঃ নং',
    'trainee_name' => 'প্রশিক্ষণার্থীর নাম',
    'designation' => 'পদবী',
    'address' => 'কর্মস্থল/ঠিকানা',
    'mobile' => 'মোবাইল নং',
    'tribe' => 'উপজাতি',
    'yes/no' => 'হ্যাঁ/না',
    'age' => 'বয়স',

];
?>