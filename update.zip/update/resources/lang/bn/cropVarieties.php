<?php
return [
    'crops_varieties_name' => 'ফসলের বিভিন্ন রকমের নাম',
    'ex_crops_varieties_name' => 'ফসলের বিভিন্নতা নাম এখানে',
    'crops_name' => 'ফসলের নাম',
    'view_crops_varieties' => 'ফসলের বিভিন্নতা দেখুন',
    'edit_crops_varieties' => 'ফসলের বিভিন্নতা এডিট করুন',
    'delete_crops_varieties' => 'ফসলের বিভিন্নতা বাদ দিন',
    'create_crops_varieties' => 'ফসলের বিভিন্নতা তৈরি করুন',
];
?>