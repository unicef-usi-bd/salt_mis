<?php
return [
    'name' => 'নাম',
    'address' => 'ঠিকানা',
    'email' => 'ইমেইল',
    'fax' => 'ফ্যাক্স',
    'org_type' => 'প্রতিষ্ঠানের টাইপ',
    'slogan' => 'স্লোগ্যান',
    'website' => 'ওয়েবসাইট',
    'logo' => 'লোগো',
    'phone' => 'ফোন',
    'bank_info' => 'ব্যাংকের তথ্য',
    'bank_name' => 'ব্যাংকের নাম',
    'branch_name' => 'শাখার নাম',
    'account_no' => 'হিসাব নাম্বার',
    'route_no' => 'রুট নং',
    'organisation_create' => 'প্রতিষ্ঠান তৈরি করুন',
    'view_organisation' => 'প্রতিষ্ঠান দেখুন',
    'edit_organisation' => 'প্রতিষ্ঠান সম্পাদনা করুন',
    'delete_organisation' => 'প্রতিষ্ঠান বাদ দিন',
    'select_one' => 'একটা নির্বাচন করুন'
];
?>