<?php
return [
    'start_date' => 'শুরুর তারিখ',
    'end_date' => 'শেষ তারিখ',
    'current_year' => 'বর্তমান বছর',
    'is_current' => 'সাম্প্রতিক',
    'year_name' => 'বছরের নাম',
    'ex_financial_year_name' => 'উদাহরণ: - এখানে আর্থিক বছরের নাম',
];
?>