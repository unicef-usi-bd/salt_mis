<?php
return [
    'union_name' => 'ইউনিয়নের নাম',
    'grade' => 'প্রাপ্ত গ্রেড (সিআইজি সংখ্যা)',
    'veryGood' => 'খুব ভাল',
    'good' => 'ভাল',
    'medium' => 'মধ্যম',
    'notGood' => 'ভাল নয়',
    'totalCig' => 'মোট সিআইজি',

];
?>