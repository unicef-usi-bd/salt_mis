<?php
return [
    'activity_type' => 'কার্যকলাপ প্রকার',
    'unit_cost' => 'একক খরচ',
    'cost_center_type' => 'খরচ কেন্দ্র প্রকার',
    'ex_unit_cost' => 'উদাহরণ: - একক খরচ',
    'technology_unit_cost' => 'প্রযুক্তি ইউনিট খরচ তৈরি করুন',
    'edit_technology_cost' => 'প্রযুক্তি ইউনিট খরচ সম্পাদনা করুন',
    'view_technology_cost' => 'প্রযুক্তি ইউনিট খরচ দেখুন',
    'delete_technology_cost' => 'প্রযুক্তি ইউনিট খরচ মুছুন'
];
?>