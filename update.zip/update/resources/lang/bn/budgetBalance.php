<?php
return [
    'ecode' => 'অর্থনৈতিক কোড',
    'budget_amount' => 'বাজেট পরিমাণ',
    'allocation_amount' => 'বরাদ্দ পরিমাণ',
    'remain_amount' => 'অবশিষ্ট উদ্বৃত্ত অংশ',

];
?>