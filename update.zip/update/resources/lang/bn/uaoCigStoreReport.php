<?php
return [
    'cigStore' => 'সিআইজি সঞ্চয় ও রেজি. প্রতিবেদন	',
    'cigNumber' => 'সিআইজি সংখ্যা',
];
?>