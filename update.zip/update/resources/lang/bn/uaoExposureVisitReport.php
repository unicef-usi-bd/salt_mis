<?php
return [
    'exposure_visit' => 'এক্সপোজার ভিজিট প্রতিবেদন',
    'place' => 'স্থান',
    'participants_type' => 'পার্টিসিপেন্টদের ধরণ',
    'total_participants_present' => 'উপস্থিত মোট পার্টিসিপেন্ট সংখ্যা',
    'participants_ethnic_present' => 'পার্টিসিপেন্টদের মধ্যে ক্ষুদ্র নৃ-গোষ্ঠির কতজন',
];
?>