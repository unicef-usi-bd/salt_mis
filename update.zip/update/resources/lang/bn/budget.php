<?php
return [
    'financial_year' => 'আর্থিক বছর',
    'source_type' => 'উৎসের টাইপ',
    'budget_type' => 'বাজেটের টাইপ',
    'amount' => 'পরিমাণ',
    'govt' => 'সরকার',
    'rpa' => 'আরপিএ ',
    'total_available' => 'মোট অবশিষ্ট',
    'adp_amount' => 'এডপ পরিমাণ',
    'budget_create' => 'বাজেট তৈরি করুন',
    'view_budget' => 'বাজেট দেখুন',
    'edit_budget' => 'এডিট বাজেট',
    'delete_budget' => 'বাজেট বাদ দিন',
    'adp_budget_date' => 'এডপ বাজেটের তারিখ',
    'revised_budget_date' => 'সংশোধিত বাজেট তারিখ',
    'revised_budget_amount' => 'সংশোধিত পরিমাণ',
    'technology' => 'প্রযুক্তি',
];
?>