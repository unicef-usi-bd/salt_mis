<?php
return [
    'upazilla_type' => 'উপজেলা প্রকার',
    'cost_center_user' => 'খরচ কেন্দ্র ব্যবহারকারীর তালিকা',
    'account_name' => 'হিসাবের নাম'
];
?>