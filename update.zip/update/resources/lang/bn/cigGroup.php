<?php
return [
    'cig_name' => 'সিআইজির নাম',
    'upazilla' => 'উপজেলা',
    'union' => 'ইউনিয়ন',
    'village' => 'গ্রাম',
    'region' => 'অঞ্চল',
    'district' => 'জেলা',
    'cig_type' => 'সিআইজি প্রকার',
    'cig' => 'সিআইজি',
    'establish_date' => 'প্রতিষ্ঠা তারিখ',
    'bank_name' => 'ব্যাংকের নাম',
    'branch_name' => 'শাখা',
    'bank_account' => 'হিসাব নাম্বার',
    'cig_create' => 'সিআইজি তৈরি করুন',
    'active_status' => 'সক্রিয় স্টেটাস',
    'ex_village_name' => 'উদাহরণ: - গ্রামের নাম এখানে',
    'ex_cig_name' => 'উদাহরণ: - সিআইজি নাম এখানে',
    'ex_bank_account' => 'উদাহরণ: - এখানে ব্যাংক অ্যাকাউন্ট',
    'view_cig' => 'সিআইজি দেখুন',
    'edit_cig' => 'এডিট সিআইজি',
    'delete_cig' => 'সিআইজি বাদ দিন',
    'cig_list' => 'সিআইজি তালিকা',
    'cig_gender' => 'সিআইজি লিঙ্গ'
];
?>