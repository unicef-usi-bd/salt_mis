<?php
return[
    'trainee_category_name' => 'প্রশিক্ষন বিভাগের নাম',
    'cost_center_type' => 'খরচ কেন্দ্রের প্রকার',
    'trainee_list' => 'প্রশিক্ষনের তালিকা',
    'view' => 'প্রশিক্ষন বিভাগ দেখুন',
    'edit' => 'প্রশিক্ষন বিভাগ সম্পাদনা করুন',
    'delete' => 'প্রশিক্ষন বিভাগ মুছে দিন',
    'trainee_category' => 'প্রশিক্ষণ বিভাগ তৈরি করুন',
    'trainee_category1' => 'প্রশিক্ষণ বিভাগ'
];