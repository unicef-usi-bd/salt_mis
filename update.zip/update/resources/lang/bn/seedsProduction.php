<?php
return [
    'production_date' => 'উৎপাদন তারিখ',
    'seeds_type' => 'বীজ টাইপ',
    'quantity' => 'পরিমাণ',
    'view_seeds_production' => 'বীজ উৎপাদন দেখুন',
    'create_seeds_production' => 'বীজ উৎপাদন তৈরি করুন',
    'date' => 'তারিখ',
    'comments' => 'মন্তব্য',
    'edit_seeds_production' => 'বীজ উৎপাদন এডিট করুন',
    'delete_seeds_production' => 'বীজ উৎপাদন মুছে ফেলুন',
    'ex_quantity' => 'পরিমাণ এখানে',
    'ex_comments' => 'মন্তব্য এখানে',
];
?>