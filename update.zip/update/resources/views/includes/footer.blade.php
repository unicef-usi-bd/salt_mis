<div class="footer" style="margin-top: 200px;">
	@include('masterGlobal.modalGlobal')
	<div class="footer-inner">
		<div class="footer-content" style="padding: 0!important;">
            <div class="container-fluid" style="padding: 0!important;">
                <img class="img-responsive" src="{{ url('assets/images/salt_login/footer.png') }}"/>
            </div>
		</div>
	</div>
</div>
